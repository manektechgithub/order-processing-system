<template>
    <CFooter :fixed="false">
        <div>
            <span>Order processing system</span>
        </div>
    </CFooter>
</template>

<script>
export default {
    name: 'TheFooter'
}
</script>
